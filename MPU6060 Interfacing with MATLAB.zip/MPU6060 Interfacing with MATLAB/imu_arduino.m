a = arduino()
fs = 100;
imu = mpu9250(a, 'SampleRate', fs, 'OutputFormat', 'matrix')
